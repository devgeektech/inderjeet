<?php


namespace Drupal\singpost_toolbox_track_and_trace\Frontend\Controller;


use Drupal\Core\Controller\ControllerBase;

/**
 * Class TrackAndTraceController
 *
 * @package Drupal\singpost_toolbox_track_and_trace\Controller
 */
class TrackAndTraceController extends ControllerBase{

	/**
	 * @return array
	 */
	public function index(){
		return [];
	}
}