<?php

namespace Drupal\singpost_announcements\Model;

use Drupal\Core\Entity\Sql\SqlContentEntityStorage;

/**
 * Defines the storage handler class for singpost_announcement entities.
 */
class AnnouncementStorage extends SqlContentEntityStorage{

}
