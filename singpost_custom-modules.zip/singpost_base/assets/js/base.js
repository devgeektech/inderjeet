(function ($) {
    "use strict";


})(jQuery);